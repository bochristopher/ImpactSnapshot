# 🚀 Team Setup Guide - 4-Step Monitoring Demo

## Quick Start (5 minutes)

### 1. Clone the Repository
```bash
git clone <repository-url>
cd openai_project
```

### 2. Set Up Environment
```bash
# Copy the template and add your API key
cp .env.template .env
# Edit .env file and replace 'your_api_key_here' with your actual OpenAI API key
```

### 3. Install Dependencies
```bash
pip3 install -r requirements.txt
```

### 4. Run the Demo
```bash
python3 demo_script.py
```

### 5. Open in Browser
Go to: `http://localhost:5000`

## 🎯 Demo Flow

1. **Click "Next Step"** - Error spike appears
2. **Click "Next Step"** - Revenue risk detected  
3. **Click "Rollback"** - System recovery begins
4. **Watch** - System recovers automatically

## 🔑 Getting Your OpenAI API Key

1. Go to [platform.openai.com](https://platform.openai.com/)
2. Sign in or create account
3. Navigate to "API Keys"
4. Create new secret key
5. Copy and paste into your `.env` file

## 🛠️ Troubleshooting

- **Port 5000 in use?** Change the port in `demo_script.py`
- **API key not working?** Check your billing/quotas on OpenAI
- **Dependencies issues?** Try `pip3 install --upgrade pip` first

## 📁 Project Structure

- `demo_script.py` - Main Flask application
- `templates/demo.html` - Interactive web interface
- `.env` - Your API key (create from .env.template)
- `requirements.txt` - Python dependencies

## 🤝 Sharing with Others

- The `.env` file is automatically ignored by git
- Each team member needs their own API key
- Demo works offline once dependencies are installed 