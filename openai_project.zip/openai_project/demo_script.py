from flask import Flask, render_template, jsonify, request
import time
import threading
import random

app = Flask(__name__)

# Global state for demo
demo_state = {
    'step': 1,
    'error_spike': False,
    'revenue_risk': False,
    'rollback_triggered': False,
    'system_recovered': False
}

@app.route('/')
def index():
    return render_template('demo.html')

@app.route('/api/status')
def get_status():
    return jsonify(demo_state)

@app.route('/api/next-step')
def next_step():
    if demo_state['step'] < 4:
        demo_state['step'] += 1
        
        # Update state based on step
        if demo_state['step'] == 2:
            demo_state['error_spike'] = True
        elif demo_state['step'] == 3:
            demo_state['revenue_risk'] = True
        elif demo_state['step'] == 4:
            demo_state['rollback_triggered'] = True
            # Simulate recovery after rollback
            threading.Timer(2.0, recover_system).start()
    
    return jsonify(demo_state)

@app.route('/api/rollback')
def trigger_rollback():
    demo_state['rollback_triggered'] = True
    demo_state['step'] = 4
    # Simulate recovery after rollback
    threading.Timer(2.0, recover_system).start()
    return jsonify(demo_state)

def recover_system():
    demo_state['error_spike'] = False
    demo_state['revenue_risk'] = False
    demo_state['system_recovered'] = True

@app.route('/api/reset')
def reset_demo():
    global demo_state
    demo_state = {
        'step': 1,
        'error_spike': False,
        'revenue_risk': False,
        'rollback_triggered': False,
        'system_recovered': False
    }
    return jsonify(demo_state)

if __name__ == '__main__':
    app.run(debug=True, port=5000) 