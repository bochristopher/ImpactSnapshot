# OpenAI Python Project

A secure Python project template for working with the OpenAI API.

## Setup Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Up Your API Key
1. Open the `.env` file in this directory
2. Replace `your_api_key_here` with your actual OpenAI API key
3. Save the file

**Important:** Never commit your API key to version control. The `.env` file is already added to `.gitignore`.

### 3. Run the Example
```bash
python main.py
```

## Project Structure
- `main.py` - Example script showing how to use the OpenAI API
- `.env` - Environment variables file (contains your API key)
- `requirements.txt` - Python dependencies
- `.gitignore` - Prevents sensitive files from being committed

## Security Notes
- ✅ API key is stored in environment variables
- ✅ `.env` file is excluded from version control
- ✅ No hardcoded secrets in the source code

## Getting Your OpenAI API Key
1. Go to [OpenAI Platform](https://platform.openai.com/)
2. Sign in or create an account
3. Navigate to "API Keys" in your dashboard
4. Create a new API key
5. Copy the key and paste it in your `.env` file 