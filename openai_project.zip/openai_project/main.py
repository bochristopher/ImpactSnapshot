import os
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env file
load_dotenv()

def main():
    # Get API key from environment variable
    api_key = os.getenv('OPENAI_API_KEY')
    
    if not api_key or api_key == 'your_api_key_here':
        print("❌ Error: Please set your OpenAI API key in the .env file")
        print("1. Open the .env file")
        print("2. Replace 'your_api_key_here' with your actual API key")
        print("3. Save the file and run this script again")
        return
    
    # Initialize OpenAI client
    client = OpenAI(api_key=api_key)
    
    try:
        # Example: Make a simple API call
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": "Hello! Say something nice."}
            ]
        )
        
        print("✅ API call successful!")
        print(f"Response: {response.choices[0].message.content}")
        
    except Exception as e:
        print(f"❌ Error making API call: {e}")

if __name__ == "__main__":
    main() 